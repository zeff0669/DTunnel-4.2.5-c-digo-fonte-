#include "async.h"

namespace cpr {

CPR_SINGLETON_IMPL(GlobalThreadPool)

} // namespace cpr
